﻿using FullStack.Dto;
using FullStack.EmpService;
using FullStack.ResponseType;
using Microsoft.AspNetCore.Mvc;

namespace FullStack.Controllers
{

    [ApiController]
    [Route("[controller]")]
    public class EmployeeController : Controller
    {
        private readonly IEmployeeService _employeeService;

        public EmployeeController(IEmployeeService employeeService)
        {
            _employeeService = employeeService;
        }
        /// <summary>
        /// GetEmployees
        /// </summary>
        /// <returns></returns>
        [HttpGet("GetEmployees")]
        public Response<List<EmployeeDto>> GetEmployees()
        {
            return _employeeService.GetEmployees();
        }
    }
}

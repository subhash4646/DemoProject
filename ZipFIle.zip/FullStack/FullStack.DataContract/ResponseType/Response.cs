﻿using System.ComponentModel.DataAnnotations;

namespace FullStack.ResponseType
{
    public class Response
    {
        public bool IsSuccess { get; set; }
        public string? Message { get; set; }
        public ApiResultStatusCode StatusCode { get; set; }
    }
    public sealed class Response<TReturn> : Response
    {
        public TReturn? Data { get; set; }
    }

    public enum ApiResultStatusCode
    {
        [Display(Name = "The operation was carried out successfully")]
        Success = 200,
        [Display(Name = "Error on Server")]
        ServerError = 500,
        [Display(Name = "Sending Parameters are not valid")]
        BadRequest = 400,
        [Display(Name = "Not Found")]
        NotFound = 404,
        [Display(Name = "The list is empty")]
        ListEmpty = 304,
        [Display(Name = "Error turned into payment")]
        LogicError = 5,
        [Display(Name = "Identity error")]
        UnAuthorized = 401,
    }
}

﻿namespace FullStack.DataLib.Repository
{
    public interface IRepositoryContext
    {
    }
}
﻿
using FullStack.Data;
using FullStack.Dto;
using FullStack.ResponseType;

namespace FullStack.EmpService
{
    public class EmployeeService : IEmployeeService
    {
        private readonly FullStackDbContext dbContext;

        public EmployeeService(FullStackDbContext _dbContext)
        {
            dbContext = _dbContext;

        }
        public Response<List<EmployeeDto>> GetEmployees()
        {
            Response<List<EmployeeDto>> response = new Response<List<EmployeeDto>>();
            try
            {
                List<EmployeeDto> dtos = new List<EmployeeDto>();
                dbContext.Employee.ToList().ForEach(item =>
                {
                    dtos.Add(new EmployeeDto
                    {
                        EmpName = item?.EmpName,
                        EmpId = item.EmpId,
                        Salary = item?.Salary,
                    });
                });
                response.IsSuccess = true;
                response.Message = "Successfully fetch data";
                response.StatusCode = ApiResultStatusCode.Success;
                response.Data = dtos;
            }
            catch (Exception ex)
            {
                throw;
            }
            return response;
        }
    }
}
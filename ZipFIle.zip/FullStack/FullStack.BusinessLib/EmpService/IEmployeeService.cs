﻿using FullStack.Dto;
using FullStack.ResponseType;

namespace FullStack.EmpService
{
    public interface IEmployeeService
    {
        public Response<List<EmployeeDto>> GetEmployees();
    }
}